As it contains massive changes you need to update the full file. Make sure you have the backup of previous asset files and database before replacing any files.

Changes we made :
[FIX] Manual Payment description not showing for user.
[FIX] Creating milestones and paying milestone payment before accepting the escrow.
[FIX] Charge cap invalid calculation.
[FIX] Wrong transaction type for milestone payment.
[FIX] Multiple time payment for single milestone via manual payment method.
[FIX] Invalid rest amount value while creating new milestone.

[ADD] Subscription system added.
[ADD] Multilingual feature enable/disable.
[ADD] Dynamic secondary color.
[ADD] KYC verification system.
[ADD] Maintenance mode system added.

[REMOVE] App section removed

[PATCH] Minor changes in the front end.
[PATCH] Admin dashboard.
[PATCH] Admin panel UI.
[PATCH] Email & SMS notification sending system
[PATCH] Updated to Latest Laravel Version.